# Update Log

## April 01st - 20th

- Added SQL Data
- Added Basic GUI
- Added Data Interfacing Login
- Added Local Dara Interfacing Login
- Updated GUI for a more pleasing look
- [BUG] GUI has tabbing issue with bunifu buttons. DLL is not supported
- [BUG] Bunifu buttons have transparency issues
- SQL Data Updated for searching ability

## April 28/04/2019

- Added User Specific Login
- Data Tabs for edditing data. /Add Data/Add User/
- Data Can now be edited from viewing grids. IF the user is a teacher or admin
- Cleaned up code, and made streamline switching between forms
- Created Error Messege for Add Data when `no data given`

## April 29/04/2019

- Updated `ReadMe` to current
- Updated `UpdateLog` to current

- Ready for submission
